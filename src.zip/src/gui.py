

if __name__ == '__main__':
    # start UI
    import LtMAO.prettyUI
    LtMAO.prettyUI.start()
