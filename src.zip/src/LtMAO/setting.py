import sys
import os
import os.path
import json
import requests
import zipfile

LOG = print


class SETTINGS:
    __settings__ = {}
    local_dir = './prefs'
    local_file = f'{local_dir}/settings.json'

    @staticmethod
    def get(key, default):
        if key in SETTINGS.__settings__:
            return SETTINGS.__settings__[key]
        return default

    @staticmethod
    def set(key, value):
        SETTINGS.__settings__[key] = value

    @staticmethod
    def load():
        with open(SETTINGS.local_file, 'r', encoding='utf-8') as f:
            SETTINGS.__settings__ = json.load(f)
        LOG(f'setting: Done: Load {SETTINGS.local_file}')

    @staticmethod
    def save():
        with open(SETTINGS.local_file, 'w+', encoding='utf-8') as f:
            json.dump(SETTINGS.__settings__, f, indent=4)
        LOG(f'setting: Done: Save {SETTINGS.local_file}')


def get(key, default): return SETTINGS.get(key, default)
def set(key, value): SETTINGS.set(key, value)


load = SETTINGS.load
save = SETTINGS.save

def to_human(size): return str(size >> ((max(size.bit_length()-1, 0)//10)*10)) + \
    ["", " KB", " MB", " GB", " TB", " PB",
        " EB"][max(size.bit_length()-1, 0)//10]

def redownload_ltmao():
    # download
    remote_file = 'https://github.com/tarngaina/LtMAO/archive/refs/heads/master.zip'
    local_file = './prefs/master.zip'
    LOG(f'setting: Running: Download {local_file}')
    get = requests.get(remote_file, stream=True)
    get.raise_for_status()
    bytes_downloaded = 0
    chunk_size = 1024**2*5
    bytes_downloaded_log = 0
    bytes_downloaded_log_limit = 1024**2
    with open(local_file, 'wb') as f:
        for chunk in get.iter_content(chunk_size):
            chunk_length = len(chunk)
            bytes_downloaded += chunk_length
            f.write(chunk)
            bytes_downloaded_log += chunk_length
            if bytes_downloaded_log > bytes_downloaded_log_limit:
                LOG(
                    f'setting: Downloading: {remote_file}: {to_human(bytes_downloaded)}')
                bytes_downloaded_log = 0
    LOG(f'setting: Done: Download {local_file}')
    # extract
    LOG(f'setting: Running: Extract {local_file}')
    zip_root = 'LtMAO-master/'
    with zipfile.ZipFile(local_file) as z:
        for z_info in z.infolist():
            if z_info.filename == zip_root:
                continue
            z_info.filename = z_info.filename.replace(zip_root, '')
            z.extract(z_info, '.')
    LOG(f'setting: Done: Extract {local_file}')
    # restart
    LOG(f'setting: Done: Download {local_file}')
    os.system(os.path.join(os.path.abspath(os.path.curdir), 'start.bat'))
    
    sys.exit(0)


def prepare(_LOG):
    # function need to call first
    global LOG
    LOG = _LOG
    # ensure folder
    os.makedirs(SETTINGS.local_dir, exist_ok=True)
    # ensure file
    if not os.path.exists(SETTINGS.local_file):
        with open(SETTINGS.local_file, 'w+') as f:
            f.write('{}')
    load()
    save()
