if __name__ == '__main__':
    from LtMAO import lol2fbx
    
    lol2fbx.fbx_to_skin('D:/test/eminem_flipped_normsl.fbx')